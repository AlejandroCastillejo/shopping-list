# a3sec technical test

## Installation

To intall the app, first unzip the package and open a terminal on the root folder (which contains the 'package.json' file).  
Then run: `yarn` or `npm install`.

## Run the app

To run the app, open a terminal on the root folder and use yarn or npm:
`yarn start` or `npm start`.
The app will now be running on localhost:3000
